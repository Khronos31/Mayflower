-- LuaRocks configuration

rocks_trees = {
   { name = "user", root = home .. "/.luarocks" };
   { name = "system", root = "/var/jb/usr/local" };
}
variables = {
   LUA_DIR = "/var/jb/usr";
   LUA_INCDIR = "/var/jb/usr/include/lua5.5";
   LUA_BINDIR = "/var/jb/usr/bin";
   LUA_VERSION = "5.5";
   LUA = "/var/jb/usr/bin/lua5.5";
}
