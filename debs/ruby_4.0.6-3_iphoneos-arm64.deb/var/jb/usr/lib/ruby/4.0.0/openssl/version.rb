# frozen_string_literal: true

module OpenSSL
  # The version string of Ruby/OpenSSL.
  VERSION = "4.0.2"
end
